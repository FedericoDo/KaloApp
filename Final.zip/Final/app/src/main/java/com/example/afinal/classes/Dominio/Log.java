package com.example.afinal.classes.Dominio;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Log {
    public List<Entry> getEntry(LocalDateTime da, LocalDateTime a) throws IOException {
        List<Entry> l = new ArrayList<Entry>();

        File f = new File("log.txt");
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        String line;

        while((line=br.readLine())!=null) {
            Entry e = new Entry();

            StringTokenizer st = new StringTokenizer(line, ";");
            //String data in iso 8601: YYYY-MM-DDTHH:MM:SS
            LocalDateTime data = LocalDateTime.parse(st.nextToken());
            if (data.isAfter(da) && data.isBefore(a)) {
                e.setDataOra(data);
                e.setMessaggio(st.nextToken());
                l.add(e);
            }
        }
        br.close();
        fr.close();
        return l;
    }

    public List<Entry> getEntry(LocalDateTime data) throws IOException {
        List<Entry> l = new ArrayList<Entry>();

        File f = new File("log.txt");
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        String line;

        while((line=br.readLine())!=null) {
            Entry e = new Entry();

            StringTokenizer st = new StringTokenizer(line, ";");
            //String data in iso 8601: YYYY-MM-DDTHH:MM:SS
            LocalDateTime da = LocalDateTime.parse(st.nextToken());
            if (da.isEqual(data)) {
                e.setDataOra(da);
                e.setMessaggio(st.nextToken());
                l.add(e);
            }
        }
        br.close();
        fr.close();
        return l;
    }
}
