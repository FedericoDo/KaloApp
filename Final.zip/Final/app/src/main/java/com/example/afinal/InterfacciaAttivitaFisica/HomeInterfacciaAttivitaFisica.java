package com.example.afinal.InterfacciaAttivitaFisica;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.afinal.InterfacciaSceltaModalita.HomeInterfacciaSceltaModalita;
import com.example.afinal.R;

import com.example.afinal.classes.Dominio.Ricetta;
import com.example.afinal.classes.GestoreFile.GestoreFile;
import java.io.IOException;
import java.time.DayOfWeek;
import java.util.Map;

public class HomeInterfacciaAttivitaFisica extends Fragment {
    GestoreFile gf;

    TextView nome;
    TextView minuti;

    @Override
    public void onStart() {
        super.onStart();
        gf = new GestoreFile(getActivity().getApplicationContext());

        nome.setText("");
        minuti.setText("");
        try {
            if(gf.getAttivitaFisicaFromFile().getNome()!=null) {
                nome.append(gf.getAttivitaFisicaFromFile().getNome());
                minuti.append(gf.getAttivitaFisicaFromFile().getMinuti()+" minuti");
            }
            else {
                nome.append("Non hai attivita fisica da svolgere!");
                minuti.append(" ");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.homeinterfacciaattivitafisica, container, false);
        nome = view.findViewById(R.id.textView40);
        minuti = view.findViewById(R.id.textView42);
        Button svolta = view.findViewById(R.id.button21);
        Button back = view.findViewById(R.id.button3);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInterfacciaSceltaModalita());
                ft.commit();
            }
        });

        svolta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    gf.resetSurplus();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                nome.setText("Non hai attivita fisica da svolgere!");
                minuti.setText(" ");
            }
        });

        return view;

    }
}
