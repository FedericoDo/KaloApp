package com.example.afinal.classes.Dominio;

import android.content.Context;

import java.io.OutputStreamWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.example.afinal.classes.GestoreFile.GestoreFile;

public class Dieta{
	private Pasto[] pasti;
	private int[] totCalorie;
	
	
	public Dieta() {super();
		pasti = new Pasto[24];
		for(int i=0; i<24; i++) pasti[i] = new Pasto();
		totCalorie = new int[6];
	}
	
	public Pasto[] getPasti() {
		return pasti;
	}
	
	public int[] getTotCalorie() {
		return totCalorie;
	}
	
	public void addPasto(Pasto p, int i) {
		pasti[i] = p;
	}
	
	public void addCalorie(int cal, int d) {
		totCalorie[d] = cal;
	}

	public void genera(Context c) {
		try {
			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(c.openFileOutput("attivitaFisica.txt", Context.MODE_PRIVATE));
			outputStreamWriter.write("0");
			outputStreamWriter.close();

			outputStreamWriter = new OutputStreamWriter(c.openFileOutput("pasti.txt", Context.MODE_PRIVATE));
			outputStreamWriter.write("");
			outputStreamWriter.close();
		}catch (Exception e){e.printStackTrace();}
		try {
			GestoreFile controller = new GestoreFile(c);
			DatiUtente Dati = controller.getDatiFromFile();
			float Fabbisogno;
			int anni = LocalDate.now().getYear() - Dati.getDataDiNascita().getYear();
			if(anni<29) {
				if(Dati.getSesso().equals("uomo")) {
					Fabbisogno = (float)15.3*Dati.getPeso()+679;
					if(Dati.getLaf().toString().equals("LEGGERO")) {
						if(Dati.isAf()) {
							Fabbisogno *=1.55;
						}else Fabbisogno *= 1.41;
					}
					else if(Dati.getLaf().toString().equals("MODERATO")) {
						if(Dati.isAf()) {
							Fabbisogno *=1.78;
						}else Fabbisogno *= 1.70;
					}
					else if(Dati.getLaf().toString().equals("PESANTE")) {
						if(Dati.isAf()) {
							Fabbisogno *=2.10;
						}else Fabbisogno *= 2.01;
					}
				}else {
					Fabbisogno = (float)14.7*Dati.getPeso()+496;
					if(Dati.getLaf().toString().equals("LEGGERO")) {
						if(Dati.isAf()) {
							Fabbisogno *=1.59;
						}else Fabbisogno *= 1.42;
					}
					else if(Dati.getLaf().toString().equals("MODERATO")) {
						if(Dati.isAf()) {
							Fabbisogno *=1.54;
						}else Fabbisogno *= 1.56;
					}
					else if(Dati.getLaf().toString().equals("PESANTE")) {
						if(Dati.isAf()) {
							Fabbisogno *=1.82;
						}else Fabbisogno *= 1.73;
					} 
				}
			}else if(anni<59) {
				if(Dati.getSesso().equals("uomo")) {
					Fabbisogno = (float)11.6*Dati.getPeso()+879;
					if(Dati.getLaf().toString().equals("LEGGERO")) {
						if(Dati.isAf()) {
							Fabbisogno *=1.55;
						}else Fabbisogno *= 1.41;
					}
					else if(Dati.getLaf().toString().equals("MODERATO")) {
						if(Dati.isAf()) {
							Fabbisogno *=1.78;
						}else Fabbisogno *= 1.70;
					}
					else if(Dati.getLaf().toString().equals("PESANTE")) {
						if(Dati.isAf()) {
							Fabbisogno *=2.10;
						}else Fabbisogno *= 2.01;
					} 
				}
				else {
					Fabbisogno = (float)8.7*Dati.getPeso()+829;		
					if(Dati.getLaf().toString().equals("LEGGERO")) {
						if(Dati.isAf()) {
							Fabbisogno *=1.59;
						}else Fabbisogno *= 1.42;
					}
					else if(Dati.getLaf().toString().equals("MODERATO")) {
						if(Dati.isAf()) {
							Fabbisogno *=1.54;
						}else Fabbisogno *= 1.56;
					}
					else if(Dati.getLaf().toString().equals("PESANTE")) {
						if(Dati.isAf()) {
							Fabbisogno *=1.82;
						}else Fabbisogno *= 1.73;
					} 
				}
			}else if(anni<74) {
				if(Dati.getSesso().equals("uomo")) {
					Fabbisogno = (float)11.9*Dati.getPeso()+700;
					if(Dati.isAf()) Fabbisogno *= 1.51;
					else Fabbisogno *= 1.40;
				}
				else {
					Fabbisogno = (float)9.2*Dati.getPeso()+688;		
					if(Dati.isAf()) Fabbisogno *= 1.56;
					else Fabbisogno *= 1.44;
				}
			}else {
				if(Dati.getSesso().equals("uomo")) {
					Fabbisogno = (float)8.4*Dati.getPeso()+819;
					if(Dati.isAf()) Fabbisogno *= 1.51;
					else Fabbisogno *= 1.33;
				}
				else {
					Fabbisogno = (float)9.8*Dati.getPeso()+624;		
					if(Dati.isAf()) Fabbisogno *= 1.51;
					else Fabbisogno *= 1.40;
				}
			}

			Random rand = new Random();
			float grammi, calrimanenti=0;
			List<Ricetta> lista = controller.getRicetteFromFile();
			List<Ricetta> colazione = new ArrayList<>();
			List<Ricetta> pranzo = new ArrayList<>();
			List<Ricetta> spuntino = new ArrayList<>();
			List<Ricetta> cena = new ArrayList<>();
			for(Ricetta r : lista){
				if(r.getTipo().toString().equals("COLAZIONE")) colazione.add(r);
				else if(r.getTipo().toString().equals("PRANZO")) pranzo.add(r);
				else if(r.getTipo().toString().equals("SPUNTINO")) spuntino.add(r);
				else if(r.getTipo().toString().equals("CENA")) cena.add(r);
			}

			Ricetta r;
			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(c.openFileOutput("dieta.txt", Context.MODE_PRIVATE));
			outputStreamWriter.write("");
			for(int p  = 0; p<24;p++) {
				switch (p%4) {
					case 0:

						ArrayList<Ricetta> copiacolazione = new ArrayList<>(colazione);
						outputStreamWriter.append("COLAZIONE");

						r = copiacolazione.get(rand.nextInt(copiacolazione.size()));
						grammi=(Fabbisogno*0.25f)/(r.getCalorie()/100);

						if (grammi > 500) {
							calrimanenti = (grammi - 500) * (r.getCalorie()/100);
							grammi=500;
						}

						pasti[p].addRicetta(r, grammi);
						outputStreamWriter.append(":"+r.getNome() + ":" + grammi);
						copiacolazione.remove(r);

						while(calrimanenti>0) {
							r = copiacolazione.get(rand.nextInt(copiacolazione.size()));
							grammi = calrimanenti/(r.getCalorie() / 100);

							if (grammi > 500) {
								calrimanenti = (grammi - 500) * (r.getCalorie()/100);
								grammi=500;
							}
							else calrimanenti=0;

							pasti[p].addRicetta(r, grammi);
							outputStreamWriter.append(":"+r.getNome() + ":" + grammi);
							copiacolazione.remove(r);
						}
						calrimanenti=0;
						outputStreamWriter.append("\n");
						break;

					case 1:

						ArrayList<Ricetta> copiapranzo = new ArrayList<>(pranzo);
						outputStreamWriter.append("PRANZO");

						r = copiapranzo.get(rand.nextInt(copiapranzo.size()));
						grammi=(Fabbisogno*0.35f)/(r.getCalorie()/100);

						if (grammi > 500) {
							calrimanenti = (grammi - 500) * (r.getCalorie()/100);
							grammi=500;
						}

						pasti[p].addRicetta(r, grammi);
						outputStreamWriter.append(":"+r.getNome() + ":" + grammi);
						copiapranzo.remove(r);

						while(calrimanenti>0) {
							r = copiapranzo.get(rand.nextInt(copiapranzo.size()));
							grammi = calrimanenti/(r.getCalorie() / 100);

							if (grammi > 500) {
								calrimanenti = (grammi - 500) * (r.getCalorie()/100);
								grammi=500;
							}
							else calrimanenti=0;

							pasti[p].addRicetta(r, grammi);
							outputStreamWriter.append(":"+r.getNome() + ":" + grammi);
							copiapranzo.remove(r);
						}
						calrimanenti=0;
						outputStreamWriter.append("\n");
						break;

					case 2:

						ArrayList<Ricetta> copiaspuntino = new ArrayList<>(spuntino);
						outputStreamWriter.append("SPUNTINO");

						r = copiaspuntino.get(rand.nextInt(copiaspuntino.size()));
						grammi=(Fabbisogno*0.1f)/(r.getCalorie()/100);

						if (grammi > 500) {
							calrimanenti = (grammi - 500) * (r.getCalorie()/100);
							grammi=500;
						}

						pasti[p].addRicetta(r, grammi);
						outputStreamWriter.append(":"+r.getNome() + ":" + grammi);
						copiaspuntino.remove(r);

						while(calrimanenti>0) {
							r = copiaspuntino.get(rand.nextInt(copiaspuntino.size()));
							grammi = calrimanenti/(r.getCalorie() / 100);

							if (grammi > 500) {
								calrimanenti = (grammi - 500) * (r.getCalorie()/100);
								grammi=500;
							}
							else calrimanenti=0;

							pasti[p].addRicetta(r, grammi);
							outputStreamWriter.append(":"+r.getNome() + ":" + grammi);
							copiaspuntino.remove(r);
						}
						calrimanenti=0;
						outputStreamWriter.append("\n");
						break;

					case 3:

						ArrayList<Ricetta> copiacena = new ArrayList<>(cena);
						outputStreamWriter.append("CENA");

						r = copiacena.get(rand.nextInt(copiacena.size()));
						grammi=(Fabbisogno*0.3f)/(r.getCalorie()/100);

						if (grammi > 500) {
							calrimanenti = (grammi - 500) * (r.getCalorie()/100);
							grammi=500;
						}

						pasti[p].addRicetta(r, grammi);
						outputStreamWriter.append(":"+r.getNome() + ":" + grammi);
						copiacena.remove(r);

						while(calrimanenti>0) {
							r = copiacena.get(rand.nextInt(copiacena.size()));
							grammi = calrimanenti/(r.getCalorie() / 100);

							if (grammi > 500) {
								calrimanenti = (grammi - 500) * (r.getCalorie()/100);
								grammi=500;
							}
							else calrimanenti=0;

							pasti[p].addRicetta(r, grammi);
							outputStreamWriter.append(":"+r.getNome() + ":" + grammi);
							copiacena.remove(r);
						}
						calrimanenti=0;
						if(p!=23) outputStreamWriter.append("\n");
						break;

				}
			}
			outputStreamWriter.close();
			
		}catch(Exception e) {e.printStackTrace();}
	}
}