package com.example.afinal.InterfacciaInserimentoDati;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.afinal.R;

import com.example.afinal.classes.Dominio.Alimento;
import com.example.afinal.classes.Dominio.Tipo;
import com.example.afinal.classes.GestoreFile.GestoreFile;
import com.example.afinal.classes.InserimentoDati.InserimentoDatiController;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ViewRicetta extends Fragment {
    InserimentoDatiController inserimento;
    GestoreFile controller;
    List<Alimento> alimenti;
    String nomeR = null;
    Tipo tipoR = null;
    List<String> nomi = new ArrayList<String>();
    List<Float> lQuantita = new ArrayList<Float>();
    private ArrayAdapter<String> spinnerAdapter;
    Spinner sp;

    @Override
    public void onStart() {
        super.onStart();
        controller = new GestoreFile(getActivity().getApplicationContext());
        inserimento = new InserimentoDatiController(getActivity().getApplicationContext());

        try {
            alimenti = controller.getAlimentiFromFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        for(Alimento a: alimenti){
            spinnerAdapter.add(a.getNome());
        }
        sp.setAdapter(spinnerAdapter);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.viewricetta, container, false);
        EditText nomeRicetta = view.findViewById(R.id.editTextTextPersonName2);
        EditText tipoRicetta = view.findViewById(R.id.editTextTextPersonName17);

        sp = view.findViewById(R.id.spinner);
        spinnerAdapter = new ArrayAdapter<String>(this.getContext(), R.layout.row);


        EditText quantita = view.findViewById(R.id.editTextTextPersonName4);
        Button addIngrediente = view.findViewById(R.id.button13);
        Button addRicetta = view.findViewById(R.id.button14);
        Button back = view.findViewById(R.id.button7);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInserimentoDati());
                ft.commit();
            }
        });

        addIngrediente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(nomeR==null && !nomeRicetta.getText().toString().isEmpty()){
                    nomeR = nomeRicetta.getText().toString();
                }
                else if(nomeR==null){
                    new NessunNome().show(
                            getChildFragmentManager(), NessunNome.TAG);
                    return;
                }

                if(tipoR==null && !tipoRicetta.getText().toString().isEmpty()){
                    try {
                        tipoR = Tipo.valueOf(tipoRicetta.getText().toString());
                    }
                    catch(IllegalArgumentException e) {
                        new TipoNonValido().show(
                                getChildFragmentManager(), TipoNonValido.TAG);
                        return;
                    }
                }
                else if(tipoR==null){
                    new NessunTipo().show(
                            getChildFragmentManager(), NessunTipo.TAG);
                    return;
                }


                TextView p1 = view.findViewById(R.id.rowtext);
                nomi.add(p1.getText().toString());
                try{
                    Float.parseFloat(quantita.getText().toString());
                }catch(NumberFormatException e) {
                    new QuantNonValida().show(
                            getChildFragmentManager(), QuantNonValida.TAG);
                    return;
                }
                lQuantita.add(Float.parseFloat(quantita.getText().toString()));
                quantita.setText("");
            }
        });

        addRicetta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nomi.isEmpty()){
                    new NoIngredienti().show(
                            getChildFragmentManager(), NoIngredienti.TAG);
                    return;
                }

                inserimento.inserisciRicetta(nomeR, nomi, lQuantita, tipoR);
                nomeR=null;
                tipoR=null;
                nomi.clear();
                lQuantita.clear();
                nomeRicetta.setText("");
                tipoRicetta.setText("");
                //nomeAlimento.setText("");
                quantita.setText("");
            }
        });

        return view;
    }

    public static class NessunNome extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Non hai inserito un nome per la ricetta")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "NessunNome";
    }

    public static class TipoNonValido extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Il tipo inserito è di un formato non valido")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "TipoNonValido";
    }

    public static class NessunTipo extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Non hai inserito nessun tipo per la ricetta")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "NessunTipo";
    }

    public static class QuantNonValida extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Il valore passato come quantità non è un float")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "QuantNonValida";
    }

    public static class AlimentoNull extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("L'alimento specificato non è esistente")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "AlimentoNull";
    }

    public static class NoIngredienti extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Non hai aggiunto nessun ingrediente")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "NoIngredienti";
    }
}
