package com.example.afinal.classes.Dominio;
 
public enum Laf {
	//impiegati, lib. profess
	LEGGERO("leggero"),
	//casalinghi, add. vendita
	MODERATO("moderato"),
	//intensa manovali, operatori
	PESANTE("pesante");

	private String laf;

	Laf(String string) {
		this.laf = string;
	}

	public String toString()
	{ return laf; }
}
