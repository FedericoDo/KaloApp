package com.example.afinal.InterfacciaInserimentoDati;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.afinal.InterfacciaSceltaModalita.HomeInterfacciaSceltaModalita;
import com.example.afinal.R;

public class HomeInserimentoDati extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.homeinserimentodati, container, false);
        Button ricetta = view.findViewById(R.id.button10);
        Button pasto = view.findViewById(R.id.button12);
        Button dati = view.findViewById(R.id.button11);
        Button acqua = view.findViewById(R.id.button8);
        Button back = view.findViewById(R.id.button2);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInterfacciaSceltaModalita());
                ft.commit();
            }
        });

        acqua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new ViewAcqua());
                ft.commit();
            }
        });

        ricetta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new ViewRicetta());
                ft.commit();
            }
        });

        pasto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new ViewPasto());
                ft.commit();
            }
        });

        dati.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new ViewDatiProfilo());
                ft.commit();
            }
        });

        return view;
    }
}
