package com.example.afinal.classes.Dominio;

import java.util.HashMap;
import java.util.Map;

public class Pasto{
	
	private Tipo tipo;
	private Map<Ricetta, Float> ricette;
	
	public Pasto() {
		ricette = new HashMap<Ricetta, Float>();
	}

	public void setTipo(Tipo t) {
		tipo = t;
	}
	public Tipo getTipo() {
		return tipo;
	}

	public Map<Ricetta, Float> getRicette() {
		return ricette;
	}

	public void setRicette(Map<Ricetta, Float> ricette) {
		this.ricette = ricette;
	}
	
	public float getCalorie() {
		float res = 0;

		for(Map.Entry<Ricetta, Float> e: ricette.entrySet()){
			res += (e.getKey().getCalorie()/100)*e.getValue();
		}

		return res;
	}
	
	public void addRicetta(Ricetta r, float f) {
		ricette.put(r, f);
	}
	
}