package com.example.afinal.classes;

import com.example.afinal.classes.Dominio.*;
import com.example.afinal.classes.GestoreFile.GestoreFile;
import com.example.afinal.classes.InserimentoDati.InserimentoDatiController;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class test {
    public static void main(String[] args) throws IOException {
        /*
        GestoreFile gestore = new GestoreFile();
        InserimentoDatiController controller = new InserimentoDatiController();

        //List<Alimento> lista = gestore.getAlimentiFromFile();

        System.out.println("Test getAlimenti fatto");


        DatiUtente dati = new DatiUtente();
        dati.setAf(false);
        dati.setAltezza(190);
        dati.setDataDiNascita(LocalDate.parse("1998-01-15"));
        dati.setLaf(Laf.valueOf("MODERATO"));
        dati.setPermessi(new boolean[]{true, false, true, false, true, false, true, false});
        dati.setPeso(83.4f);
        dati.setSesso("uomo");

        //controller.inserisciDatiProfilo(dati, new boolean[]{true, true, true, true, true, true});


        List<String> nomi = new ArrayList<String>();
        List<Float> quantita = new ArrayList<Float>();
        nomi.add("uovo");
        quantita.add(82f);
        nomi.add("pecorino");
        quantita.add(18f);


        Dieta d = new Dieta();
        //d.genera();


        //controller.inserisciRicetta("frittata", nomi, quantita, Tipo.PRANZO);


        //controller.inserisciPasto(true, "COLAZIONE", null);

        ///*
        Ricetta r = new Ricetta();
        r.setNome("frittata");
        r.setCalorie(178.58f);
        Pasto p = new Pasto();
        p.setTipo(Tipo.PRANZO);
        p.addRicetta(r, 3000);

        //controller.inserisciPasto(false, "PRANZO", p);
        //*/

        //controller.inserisciPasto(true, "SPUNTINO", null);
        //controller.inserisciPasto(true, "CENA", null);
    }
}
