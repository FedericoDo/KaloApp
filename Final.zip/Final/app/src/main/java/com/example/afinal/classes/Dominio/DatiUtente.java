package com.example.afinal.classes.Dominio;

import java.time.LocalDate;
import com.example.afinal.classes.Dominio.*;

public class DatiUtente {

	private int altezza;	
	private float peso;
	private String sesso;
	private LocalDate dataDiNascita;
	private Laf laf;
	private boolean af; /*---?---*/
	private AttivitaFisica attivitaFisica;
	private Dieta dieta;
	private boolean[] permessi = new boolean[8];
	
	
	public int getAltezza() {
		return altezza;
	}
	
	public void setAltezza(int altezza) {
		this.altezza = altezza;
	}
	
	public float getPeso() {
		return peso;
	}
	
	public void setPeso(float peso) {
		this.peso = peso;
	}
	
	public String getSesso() {
		return sesso;
	}
	
	public void setSesso(String sesso) {
		this.sesso = sesso;
	}
	
	public LocalDate getDataDiNascita() {
		return dataDiNascita;
	}
	
	public void setDataDiNascita(LocalDate dataDiNascita) {
		this.dataDiNascita = dataDiNascita;
	}
	
	public Laf getLaf() {
		return laf;
	}
	
	public void setLaf(Laf laf) {
		this.laf = laf;
	}
	
	public boolean isAf() {
		return af;
	}
	
	public void setAf(boolean af) {
		this.af = af;
	}
	
	public boolean[] getPermessi() {
		return permessi;
	}
	
	public void setPermessi(boolean[] permessi) {
		this.permessi = permessi;
	}
	
	public Dieta getDieta(){
	    return this.dieta;
	}
	
	public void setDieta(Dieta dieta){
	    this.dieta=dieta;
	}
	
	public AttivitaFisica getAttivitaFisica(){
	     return this.attivitaFisica;
	}
	
	public void setAttivitaFisica(AttivitaFisica attivitaFisica){
	     this.attivitaFisica = attivitaFisica;
	}
	
}