package com.example.afinal.classes.GestoreFile;

import android.content.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.StringTokenizer;

import com.example.afinal.classes.Dominio.Alimento;
import com.example.afinal.classes.Dominio.AttivitaFisica;
import com.example.afinal.classes.Dominio.DatiUtente;
import com.example.afinal.classes.Dominio.Dieta;
import com.example.afinal.classes.Dominio.Laf;
import com.example.afinal.classes.Dominio.Pasto;
import com.example.afinal.classes.Dominio.Ricetta;
import com.example.afinal.classes.Dominio.Tipo;

public class GestoreFile {
    private Context c;

    public GestoreFile(Context c) {
        this.c = c;
    }

    //Serve a prendere la lista di alimenti dal file di testo
    public List<Alimento> getAlimentiFromFile() throws IOException {
        List<Alimento> l = new ArrayList<Alimento>();
        InputStream inputStream = c.openFileInput("alimenti.txt");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader br = new BufferedReader(inputStreamReader);
        String line;

        while((line=br.readLine())!=null) {
            if(!line.equals("")) {
                StringTokenizer st = new StringTokenizer(line, ":");
                Alimento a = new Alimento();
                a.setNome(st.nextToken());
                a.setCalorie(Float.parseFloat(st.nextToken()));
                l.add(a);
            }
        }
        br.close();
        inputStreamReader.close();
        inputStream.close();
        return l;
    }

    //Serve a prendere la lista di ricette dal file di testo
    public List<Ricetta> getRicetteFromFile() throws IOException {
        List<Ricetta> l = new ArrayList<Ricetta>();
        InputStream inputStream = c.openFileInput("ricette.txt");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader br = new BufferedReader(inputStreamReader);
        String line;

        while((line=br.readLine())!=null) {
            if(!line.equals("")) {
                StringTokenizer st = new StringTokenizer(line, ":");
                Ricetta r = new Ricetta();
                r.setNome(st.nextToken());
                r.setCalorie(Float.parseFloat(st.nextToken()));
                r.setTipo(Tipo.valueOf(st.nextToken()));
                l.add(r);
            }
        }
        br.close();
        inputStreamReader.close();
        inputStream.close();
        return l;
    }

    //Serve a prendere la dieta dell'utente dal file di testo
    public Dieta getDietaFromFile() throws IOException{
        //File dieta.txt formattato così: tipo:nomeRicetta:quantita:nomeRicetta:quantita:nomeRicetta:quantita
        Dieta d = new Dieta();
        List<Ricetta> ricette = getRicetteFromFile();
        int counterPasti=0;
        int counterGiorni=0;
        int totC=0;

        InputStream inputStream = c.openFileInput("dieta.txt");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader br = new BufferedReader(inputStreamReader);
        String line;

        while((line=br.readLine())!=null) {
            if(!line.equals("")) {
                Pasto p = new Pasto();
                StringTokenizer st = new StringTokenizer(line, ":");
                String tipo = st.nextToken();
                switch (tipo) {
                    case "COLAZIONE" : p.setTipo(Tipo.COLAZIONE); break;
                    case "PRANZO" : p.setTipo(Tipo.PRANZO); break;
                    case "SPUNTINO" : p.setTipo(Tipo.SPUNTINO); break;
                    case "CENA" : p.setTipo(Tipo.CENA); break;
                }

                while (st.hasMoreTokens()) {
                    String nomeRicetta = st.nextToken();
                    for (Ricetta r : ricette) {
                        if (r.getNome().equals(nomeRicetta)) {
                            p.addRicetta(r, Float.parseFloat(st.nextToken()));
                            break;
                        }
                    }
                }
                totC+=p.getCalorie();
                d.addPasto(p, counterPasti);
                counterPasti++;
                if (p.getTipo() == Tipo.CENA) {  //PARENTESI
                    d.addCalorie(totC, counterGiorni);
                    totC = 0;
                    counterGiorni++;
                }
            }
        }

        br.close();
        inputStreamReader.close();
        inputStream.close();
        return d;
    }

    //questo metodo restituisce il prossimo pasto da fare
    public Pasto getPastoDaFare() throws IOException {
        int index=0;
        String tipo;
        int dayOfWeek = getDayOfWeek();
        Dieta d = getDietaFromFile();

        InputStream inputStream = c.openFileInput("pasti.txt");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader br = new BufferedReader(inputStreamReader);
        String line;
        String lastline = "";
        br.readLine();
        while((line=br.readLine())!=null) {
            lastline=line;
        }

        br.close();
        inputStreamReader.close();
        inputStream.close();

        if(lastline.isEmpty()){
            tipo="CENA";
        }
        else {
            StringTokenizer st = new StringTokenizer(lastline, ":");
            st.nextToken();
            tipo = st.nextToken();
        }

        switch(tipo){
            case "COLAZIONE" :
                tipo="pranzo";
                index=2;
                break;
            case "PRANZO" :
                tipo="spuntino";
                index=3;
                break;
            case "SPUNTINO" :
                tipo="cena";
                index=4;
                break;
            case "CENA" :
                tipo="colazione";
                index=1;
                break;
        }

        index = ((dayOfWeek*4)-5)+index;
        return d.getPasti()[index];
    }

    //Serve a prendere i dati dell'utente dal file di testo
    public DatiUtente getDatiFromFile() throws IOException {
        InputStream inputStream = c.openFileInput("DatiUtente.txt");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader br = new BufferedReader(inputStreamReader);
        DatiUtente Dati = new DatiUtente();
        String line;
        int i = 1;
        while ((line=br.readLine())!=null){
            switch(i) {
                case 1: Dati.setAltezza(Integer.parseInt(line));
                    i++;
                    break;
                case 2: Dati.setPeso(Float.parseFloat(line));
                    i++;
                    break;
                case 3: Dati.setSesso(line);
                    i++;
                    break;
                case 4: Dati.setDataDiNascita(LocalDate.parse(line));
                    i++;
                    break;
                case 5: Dati.setLaf(Laf.valueOf(line));
                    i++;
                    break;
                case 6: Dati.setAf(Boolean.parseBoolean(line));
                    i++;
                    break;
                case 7: boolean[] B = new boolean[8];
                    for(int k = 0; k<8; k++) {
                        B[k] = Boolean.parseBoolean(line.split(":")[k]);
                    }
                    Dati.setPermessi(B);
                    i++;
                    break;
            }
        }
        Dati.setAttivitaFisica(getAttivitaFisicaFromFile());
        Dati.setDieta(getDietaFromFile());
        br.close();
        inputStreamReader.close();
        inputStream.close();

        return Dati;
    }

    //Serve a prendere la lista di tutte le attività fisiche disponibili dal file
    public List<AttivitaFisica> getAllAttivita() throws IOException {
        List<AttivitaFisica> at = new ArrayList<AttivitaFisica>();
        InputStream inputStream = c.openFileInput("attivita.txt");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader br = new BufferedReader(inputStreamReader);
        String line;

        while((line=br.readLine())!=null) {
            if(!line.equals("")) {
                StringTokenizer st = new StringTokenizer(line, ":");
                AttivitaFisica a = new AttivitaFisica();
                a.setNome(st.nextToken());
                a.setCaloriePerMinuto(Float.parseFloat(st.nextToken()));
                at.add(a);
            }
        }
        br.close();
        inputStreamReader.close();
        inputStream.close();
        return at;
    }

    //serve a prendere l'attività fisica che è stata assegnata all'utente dal file
    public AttivitaFisica getAttivitaFisicaFromFile() throws IOException {
        AttivitaFisica at = new AttivitaFisica();
        InputStream inputStream = c.openFileInput("attivitaFisica.txt");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader br = new BufferedReader(inputStreamReader);
        String line;
        br.readLine(); //linea col surplus
        line=br.readLine();

        if(line!=null) {
            StringTokenizer st = new StringTokenizer(line, ":");
            at.setNome(st.nextToken());
            at.setMinuti(Integer.parseInt(st.nextToken()));
            at.setCaloriePerMinuto(getCaloriePerMinutoAttivita(at.getNome()));
        }
        br.close();
        inputStreamReader.close();
        inputStream.close();

        return at;
    }

    //serve per prendere le calorie al minuto consumate di una determinata attività fisica
    public float getCaloriePerMinutoAttivita(String nome) throws IOException {
        float cal=0;
        InputStream inputStream = c.openFileInput("attivita.txt");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader br = new BufferedReader(inputStreamReader);
        String line;

        while((line=br.readLine())!=null) {
            if(!line.equals("")) {
                StringTokenizer st = new StringTokenizer(line, ":");
                if(st.nextToken().equals(nome)){
                    cal=Float.parseFloat(st.nextToken());
                }
            }
        }
        br.close();
        inputStreamReader.close();
        inputStream.close();

        return cal;
    }

    public float getSurplusAttuale() throws IOException {
        InputStream inputStream = c.openFileInput("attivitaFisica.txt");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader br = new BufferedReader(inputStreamReader);

        float surplusAttuale = Float.parseFloat(br.readLine());

        br.close();
        inputStreamReader.close();
        inputStream.close();
        return surplusAttuale;
    }

    public void aggiornaSurplus(int day, String tipo, Pasto p) throws IOException {
        int index=0;
        float surplusAttuale = getSurplusAttuale();

        switch(tipo){
            case "COLAZIONE" :
                index=1;
                break;
            case "PRANZO" :
                index=2;
                break;
            case "SPUNTINO" :
                index=3;
                break;
            case "CENA" :
                index=4;
                break;
        }

        index = ((day*4)-5)+index;

        Dieta d = getDietaFromFile();
        Pasto pastoDaFare = d.getPasti()[index];

        if(pastoDaFare.getCalorie()<p.getCalorie()){
            System.out.println(pastoDaFare.getCalorie());
            System.out.println(p.getCalorie());
            surplusAttuale+= (p.getCalorie()-pastoDaFare.getCalorie());
        }

        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(c.openFileOutput("attivitaFisica.txt", Context.MODE_PRIVATE));
        outputStreamWriter.write(String.valueOf(surplusAttuale));
        outputStreamWriter.close();
    }

    public void resetSurplus() throws IOException {
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(c.openFileOutput("attivitaFisica.txt", Context.MODE_PRIVATE));
        outputStreamWriter.write("0");
        outputStreamWriter.close();
    }

    public int getDayOfWeek() {
        Calendar calendar = Calendar.getInstance();
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        if(dayOfWeek==1) dayOfWeek=7;
        else dayOfWeek-=1;

        return dayOfWeek;
    }
}
