package com.example.afinal.classes.Dominio;

public enum Tipo{
	COLAZIONE,
	PRANZO,
	SPUNTINO,
	CENA
}