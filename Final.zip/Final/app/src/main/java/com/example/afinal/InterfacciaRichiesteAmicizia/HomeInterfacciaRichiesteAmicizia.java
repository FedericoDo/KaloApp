package com.example.afinal.InterfacciaRichiesteAmicizia;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.afinal.InterfacciaSceltaModalita.HomeInterfacciaSceltaModalita;
import com.example.afinal.R;

import com.example.afinal.classes.GestoreFile.GestoreFile;

public class HomeInterfacciaRichiesteAmicizia extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.work_in_progress, container, false);
        Button Back = view.findViewById(R.id.button19);

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, //TODO viewAmici o finestra
                        new HomeInterfacciaSceltaModalita());
                ft.commit();
            }
        });
        return view;
    }
}
