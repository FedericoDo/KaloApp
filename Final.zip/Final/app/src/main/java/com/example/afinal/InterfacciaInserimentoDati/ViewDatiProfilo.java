package com.example.afinal.InterfacciaInserimentoDati;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.example.afinal.R;

import com.example.afinal.classes.Dominio.DatiUtente;
import com.example.afinal.classes.Dominio.Dieta;
import com.example.afinal.classes.Dominio.Laf;
import com.example.afinal.classes.GestoreFile.GestoreFile;
import com.example.afinal.classes.InserimentoDati.InserimentoDatiController;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;

public class ViewDatiProfilo extends Fragment {
    GestoreFile gf;
    InserimentoDatiController inserimento;
    DateTimeFormatter fomatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ITALY);
    DatiUtente dati = new DatiUtente();
    boolean[] permessi = new boolean[8];
    boolean[] settato = new boolean[6];

    EditText altezza;
    EditText peso;
    EditText sesso;
    EditText data;
    EditText laf;
    EditText af;

    @Override
    public void onStart() {
        super.onStart();
        gf = new GestoreFile(getActivity().getApplicationContext());
        inserimento = new InserimentoDatiController(getActivity().getApplicationContext());
        DatiUtente datiU = null;
        try {
            datiU = gf.getDatiFromFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        altezza.setHint("Attuale:"+datiU.getAltezza());
        peso.setHint("Attuale:"+datiU.getPeso());
        sesso.setHint("Attuale:"+datiU.getSesso());
        laf.setHint("Attuale:"+datiU.getLaf().toString());
        af.setHint("Attuale:"+Boolean.toString(datiU.isAf()));
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.viewdatiprofilo, container, false);
        altezza = view.findViewById(R.id.editTextTextPersonName10);
        peso = view.findViewById(R.id.editTextTextPersonName11);
        sesso = view.findViewById(R.id.editTextTextPersonName12);
        data = view.findViewById(R.id.editTextTextPersonName15);
        laf = view.findViewById(R.id.editTextTextPersonName13);
        af = view.findViewById(R.id.editTextTextPersonName14);
        CheckBox cAltezza = view.findViewById(R.id.checkBox2);
        CheckBox cPeso = view.findViewById(R.id.checkBox3);
        CheckBox cSesso = view.findViewById(R.id.checkBox4);
        CheckBox cData = view.findViewById(R.id.checkBox5);
        CheckBox cLaf = view.findViewById(R.id.checkBox6);
        CheckBox cAf = view.findViewById(R.id.checkBox7);
        CheckBox cDieta = view.findViewById(R.id.checkBox8);
        CheckBox cAttivita = view.findViewById(R.id.checkBox9);
        Button invio = view.findViewById(R.id.button17);
        Button back = view.findViewById(R.id.button5);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInserimentoDati());
                ft.commit();
            }
        });

        invio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    dati.setAltezza(Integer.parseInt(altezza.getText().toString()));
                    settato[0]=true;
                }
                catch(NumberFormatException e) {
                    settato[0]=false;
                    new AltezzaNonValida().show(
                            getChildFragmentManager(), AltezzaNonValida.TAG);
                    return;
                }
                catch(NullPointerException e) {
                    settato[0]=false;
                }

                try{
                    dati.setPeso(Float.parseFloat(peso.getText().toString()));
                    settato[1]=true;
                }
                catch(NumberFormatException e) {
                    settato[1]=false;
                    new PesoNonValido().show(
                            getChildFragmentManager(), PesoNonValido.TAG);
                    return;
                }
                catch(NullPointerException e) {
                    settato[1]=false;
                }

                if(!sesso.getText().toString().isEmpty()){
                    if(!sesso.getText().toString().equals("uomo") && !sesso.getText().toString().equals("donna")){
                        settato[2]=false;
                        new SessoNonValido().show(
                                getChildFragmentManager(), SessoNonValido.TAG);
                        return;
                    }
                    else {
                        dati.setSesso(sesso.getText().toString());
                        settato[2]=true;
                    }
                }

                try {
                    LocalDate ldt = LocalDate.parse(data.getText().toString(), fomatter);
                    String result = ldt.format(fomatter);
                    if(result.equals(data.getText().toString())){
                        dati.setDataDiNascita(ldt);
                        settato[3]=true;
                    }
                } catch (DateTimeParseException e) {
                    if(!data.getText().toString().isEmpty()){
                        settato[3]=false;
                        new DataNonValida().show(
                                getChildFragmentManager(), DataNonValida.TAG);
                        return;
                    }
                }

                if(!laf.getText().toString().isEmpty()){
                    if(!laf.getText().toString().equals("LEGGERO") && !laf.getText().toString().equals("MODERATO") && !laf.getText().toString().equals("PESANTE")){
                        settato[4]=false;
                        new LafNonValido().show(
                                getChildFragmentManager(), LafNonValido.TAG);
                        return;
                    }
                    else {
                        dati.setLaf(Laf.valueOf(laf.getText().toString()));
                        settato[4]=true;
                    }
                }

                if(!af.getText().toString().isEmpty()){
                    if(!af.getText().toString().equals("true") && !af.getText().toString().equals("false")){
                        settato[5]=false;
                        new AfNonValido().show(
                                getChildFragmentManager(), AfNonValido.TAG);
                        return;
                    }
                    else {
                        dati.setAf(Boolean.parseBoolean(af.getText().toString()));
                        settato[5]=true;
                    }
                }

                permessi[0] = cAltezza.isChecked();
                permessi[1] = cPeso.isChecked();
                permessi[2] = cSesso.isChecked();
                permessi[3] = cData.isChecked();
                permessi[4] = cLaf.isChecked();
                permessi[5] = cAf.isChecked();
                permessi[6] = cDieta.isChecked();
                permessi[7] = cAttivita.isChecked();

                dati.setPermessi(permessi);
                try {
                    inserimento.inserisciDatiProfilo(dati, settato);
                    Dieta d = new Dieta();
                    d.genera(getActivity().getApplicationContext());
                } catch (IOException e) {
                    e.printStackTrace();
                }

                dati = new DatiUtente();
                permessi = new boolean[8];
                settato = new boolean[6];
                altezza.setText("");
                peso.setText("");
                sesso.setText("");
                data.setText("");
                laf.setText("");
                af.setText("");
                DatiUtente datiU = null;
                try {
                    datiU = gf.getDatiFromFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                altezza.setHint("Attuale:"+datiU.getAltezza());
                peso.setHint("Attuale:"+datiU.getPeso());
                sesso.setHint("Attuale:"+datiU.getSesso());
                laf.setHint("Attuale:"+datiU.getLaf().toString());
                af.setHint("Attuale:"+Boolean.toString(datiU.isAf()));
            }
        });


        return view;
    }

    public static class AltezzaNonValida extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Il valore specificato per l'altezza non è valido")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "AltezzaNonValida";
    }

    public static class PesoNonValido extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Il valore specificato per il peso non è valido")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "PesoNonValido";
    }

    public static class SessoNonValido extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Il valore specificato per il sesso non è valido")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "SessoNonValido";
    }

    public static class DataNonValida extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Il valore specificato per la data non è valido")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "DataNonValida";
    }

    public static class LafNonValido extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Il valore specificato per il laf non è valido")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "LafNonValido";
    }

    public static class AfNonValido extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Il valore specificato per l'attività fisica non è valido")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "AfNonValido";
    }
}