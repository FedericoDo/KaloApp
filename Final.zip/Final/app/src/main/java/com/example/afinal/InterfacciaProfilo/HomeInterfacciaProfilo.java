package com.example.afinal.InterfacciaProfilo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.afinal.InterfacciaRichiesteAmicizia.HomeInterfacciaRichiesteAmicizia;
import com.example.afinal.InterfacciaSceltaModalita.HomeInterfacciaSceltaModalita;
import com.example.afinal.R;

//capire come distinguere e/o gestire interfaccia profilo online e offline
public class HomeInterfacciaProfilo extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.homeinterfacciaprofilo, container, false);
        Button amici = view.findViewById(R.id.button18);
        Button cercaAmici = view.findViewById(R.id.button20);
        Button impostazioni = view.findViewById(R.id.button16);
        Button back = view.findViewById(R.id.button4);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInterfacciaSceltaModalita());
                ft.commit();
            }
        });

        amici.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, //TODO viewAmici o finestra
                         new HomeInterfacciaRichiesteAmicizia());
                ft.commit();
            }
        });

        cercaAmici.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, //TODO viewCerca o finestra
                        new HomeInterfacciaRichiesteAmicizia());
                ft.commit();
            }
        });

        impostazioni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, //TODO viewImpostazioni o finestra
                        new HomeInterfacciaSceltaModalita());
                ft.commit();
            }
        });


        return view;
    }
}
