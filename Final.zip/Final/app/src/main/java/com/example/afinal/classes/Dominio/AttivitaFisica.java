package com.example.afinal.classes.Dominio;

public class AttivitaFisica{
	private String nome;
	private float caloriePerMinuto;
	private int minuti;

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public float getCaloriePerMinuto() {
		return caloriePerMinuto;
	}
	public void setCaloriePerMinuto(float caloriePerMinuto) {
		this.caloriePerMinuto = caloriePerMinuto;
	}
	public int getMinuti() {return minuti;}
	public void setMinuti(int minuti) {this.minuti = minuti;}
}