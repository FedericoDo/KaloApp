package com.example.afinal.classes.Dominio;

import java.util.List;


//forse utile classe amico? boh
public class Utente {
	private String username;	
	private String password;
	private List<String>amici;
	private DatiUtente dati;
	
	/*-----Costruttore?-----*/
	/*public Utente(String username, String pass, List<String> amici, DatiUtente dati) {
		this.username=username;
		this.password=pass;
		this.amici=amici
		this.dati=dati;
	}*/
	
    public String getUsername() {
		return username;
	}
    
	protected void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	
	protected void setPassword(String password) {		
		this.password = password;
	}
	
	public List<String> getAmici() {
		return amici;
	}
	
	public void setAmici(List<String> amici) {
		this.amici = List.copyOf(amici);
	}
	
	public DatiUtente getDati() {
		return dati;
	}
	
	public void setDati(DatiUtente dati) {
		this.dati = dati;
	}
		
	public void addAmico(String friendName) {
		if(!friendName.equals("") && friendName!=null)
		     this.amici.add(friendName);
	}
	
	public void removeAmico(String friendName) {
		if(!friendName.equals("") && friendName!=null)
		     this.amici.remove(friendName);
	}
	
}
