package com.example.afinal.InterfacciaDieta;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.afinal.InterfacciaSceltaModalita.HomeInterfacciaSceltaModalita;
import com.example.afinal.R;
import com.example.afinal.classes.Dominio.DatiUtente;
import com.example.afinal.classes.Dominio.Dieta;
import com.example.afinal.classes.Dominio.Pasto;
import com.example.afinal.classes.Dominio.Ricetta;
import com.example.afinal.classes.GestoreFile.GestoreFile;
import com.example.afinal.classes.InserimentoDati.InserimentoDatiController;

import java.io.IOException;
import java.time.DayOfWeek;
import java.util.Map;

public class HomeInterfacciaDieta extends Fragment {
    GestoreFile gf;
    Dieta d;
    Pasto[] pasti;
    int dayOfWeek;

    TextView colazione;
    TextView pranzo;
    TextView spuntino;
    TextView cena;
    Button prec;
    Button suc;

    @Override
    public void onStart() {
        super.onStart();
        gf = new GestoreFile(getActivity().getApplicationContext());
        try {
            d = gf.getDietaFromFile();
            pasti=d.getPasti();
        } catch (IOException e) {
            e.printStackTrace();
        }

        dayOfWeek = gf.getDayOfWeek();
        if(dayOfWeek==7) dayOfWeek=1;

        colazione.setText("");
        for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+1].getRicette().entrySet()){
            colazione.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
        }

        pranzo.setText("");
        for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+2].getRicette().entrySet()){
            pranzo.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
        }

        spuntino.setText("");
        for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+3].getRicette().entrySet()){
            spuntino.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
        }

        cena.setText("");
        for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+4].getRicette().entrySet()){
            cena.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
        }

        if(dayOfWeek==1) prec.setText(DayOfWeek.of(6).toString());
        else prec.setText(DayOfWeek.of(dayOfWeek-1).toString());

        if(dayOfWeek==6) suc.setText(DayOfWeek.of(1).toString());
        else suc.setText(DayOfWeek.of(dayOfWeek+1).toString());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.homeinterfacciadieta, container, false);
        colazione = view.findViewById(R.id.textView44);
        pranzo = view.findViewById(R.id.textView46);
        spuntino = view.findViewById(R.id.textView48);
        cena = view.findViewById(R.id.textView50);
        prec = view.findViewById(R.id.button24);
        suc = view.findViewById(R.id.button25);
        Button indietro = view.findViewById(R.id.button26);

        prec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dayOfWeek==1) dayOfWeek=6;
                else dayOfWeek-=1;

                colazione.setText("");
                for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+1].getRicette().entrySet()){
                    colazione.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
                }

                pranzo.setText("");
                for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+2].getRicette().entrySet()){
                    pranzo.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
                }

                spuntino.setText("");
                for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+3].getRicette().entrySet()){
                    spuntino.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
                }

                cena.setText("");
                for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+4].getRicette().entrySet()){
                    cena.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
                }

                if(dayOfWeek==1) prec.setText(DayOfWeek.of(6).toString());
                else prec.setText(DayOfWeek.of(dayOfWeek-1).toString());

                if(dayOfWeek==6) suc.setText(DayOfWeek.of(1).toString());
                else suc.setText(DayOfWeek.of(dayOfWeek+1).toString());
            }
        });

        suc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dayOfWeek==6) dayOfWeek=1;
                else dayOfWeek+=1;

                colazione.setText("");
                for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+1].getRicette().entrySet()){
                    colazione.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
                }

                pranzo.setText("");
                for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+2].getRicette().entrySet()){
                    pranzo.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
                }

                spuntino.setText("");
                for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+3].getRicette().entrySet()){
                    spuntino.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
                }

                cena.setText("");
                for(Map.Entry<Ricetta, Float> e : pasti[((dayOfWeek*4)-5)+4].getRicette().entrySet()){
                    cena.append(e.getKey().getNome() + ", " + e.getValue() + " grammi \n");
                }

                if(dayOfWeek==1) prec.setText(DayOfWeek.of(6).toString());
                else prec.setText(DayOfWeek.of(dayOfWeek-1).toString());

                if(dayOfWeek==6) suc.setText(DayOfWeek.of(1).toString());
                else suc.setText(DayOfWeek.of(dayOfWeek+1).toString());
            }
        });

        indietro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInterfacciaSceltaModalita());
                ft.commit();
            }
        });


        return view;
    }
}