package com.example.afinal.InterfacciaInserimentoDati;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.afinal.R;

import com.example.afinal.classes.Dominio.Dieta;
import com.example.afinal.classes.Dominio.Pasto;
import com.example.afinal.classes.Dominio.Ricetta;
import com.example.afinal.classes.GestoreFile.GestoreFile;
import com.example.afinal.classes.InserimentoDati.InserimentoDatiController;
import java.io.IOException;
import java.util.List;

public class ViewPasto extends Fragment {
    InserimentoDatiController inserimento;
    GestoreFile controller;
    Dieta d;
    Pasto p = new Pasto();
    List<Ricetta> ricette;
    FragmentManager fm;
    private ArrayAdapter<String> spinnerAdapter;
    Spinner sp;

    @Override
    public void onStart() {
        super.onStart();
        fm = getParentFragmentManager();
        controller = new GestoreFile(getActivity().getApplicationContext());
        inserimento = new InserimentoDatiController(getActivity().getApplicationContext());

        try {
            d = controller.getDietaFromFile();
            ricette = controller.getRicetteFromFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        for(Ricetta a: ricette){
            spinnerAdapter.add(a.getNome());
        }
        sp.setAdapter(spinnerAdapter);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.viewpasto, container, false);
        EditText quantita = view.findViewById(R.id.editTextTextPersonName9);
        Button invio = view.findViewById(R.id.button15);
        Button addRicetta = view.findViewById(R.id.button16);
        CheckBox check = view.findViewById(R.id.checkBox);
        Button back = view.findViewById(R.id.button6);

        sp = view.findViewById(R.id.spinner2);
        spinnerAdapter = new ArrayAdapter<String>(this.getContext(), R.layout.row2);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInserimentoDati());
                ft.commit();
            }
        });

        invio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(check.isChecked()){
                    try {
                        inserimento.inserisciPasto(true, controller.getPastoDaFare().getTipo().toString(), null);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else{
                    if(p.getRicette().isEmpty()) {
                        new NessunaRicetta().show(
                                getChildFragmentManager(), NessunaRicetta.TAG);
                        return;
                    }
                    try {
                        inserimento.inserisciPasto(false, controller.getPastoDaFare().getTipo().toString(), p);
                        p = new Pasto();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    quantita.setText("");
                }
                if(check.isChecked()) check.setChecked(false);
            }
        });

        addRicetta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView p1 = view.findViewById(R.id.rowtext2);

                Ricetta trovata = null;
                for(Ricetta r : ricette) {
                    if(p1.getText().toString().equals(r.getNome())){
                        trovata=r;
                    }
                }

                p.addRicetta(trovata, Float.parseFloat(quantita.getText().toString()));
                quantita.setText("");
            }
        });

        return view;
    }

    public static class RicettaNonEsistente extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("La ricetta specificata non esiste")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "RicettaNonEsistente";
    }

    public static class NessunaRicetta extends DialogFragment {
        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            return new AlertDialog.Builder(requireContext())
                    .setMessage("Non hai inserito almeno una ricetta per il pasto")
                    .setPositiveButton("Ok", (dialog, which) -> {} )
                    .create();
        }

        public static String TAG = "NessunaRicetta";
    }
}
