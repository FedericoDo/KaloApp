package com.example.afinal.InterfacciaSceltaModalita;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.afinal.InterfacciaAttivitaFisica.HomeInterfacciaAttivitaFisica;
import com.example.afinal.InterfacciaDieta.HomeInterfacciaDieta;
import com.example.afinal.InterfacciaInserimentoDati.HomeInserimentoDati;
import com.example.afinal.InterfacciaProfilo.HomeInterfacciaProfilo;
import com.example.afinal.R;

import java.io.IOException;
import java.io.OutputStreamWriter;

public class HomeInterfacciaSceltaModalita extends Fragment{
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.homeinterfacciasceltamodalita, container, false);
        Button inserimento = view.findViewById(R.id.button15);
        Button profilo = view.findViewById(R.id.button17);
        Button dieta = view.findViewById(R.id.button22);
        Button attivita = view.findViewById(R.id.button23);
        Button reset = view.findViewById(R.id.button);

        inserimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInserimentoDati());
                ft.commit();
            }
        });

        profilo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInterfacciaProfilo());
                ft.commit();
            }
        });

        dieta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInterfacciaDieta());
                ft.commit();
            }
        });

        attivita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getParentFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_container, new HomeInterfacciaAttivitaFisica());
                ft.commit();
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(getActivity().getApplicationContext().openFileOutput("alimenti.txt", Context.MODE_PRIVATE));
                    outputStreamWriter.write("uovo:128\n" +
                            "pecorino:409");
                    outputStreamWriter.close();

                    outputStreamWriter = new OutputStreamWriter(getActivity().getApplicationContext().openFileOutput("attivita.txt", Context.MODE_PRIVATE));
                    outputStreamWriter.write("corsa:16\n" +
                            "nuoto:13\n" +
                            "bici:6");
                    outputStreamWriter.close();

                    outputStreamWriter = new OutputStreamWriter(getActivity().getApplicationContext().openFileOutput("attivitaFisica.txt", Context.MODE_PRIVATE));
                    outputStreamWriter.write("0");
                    outputStreamWriter.close();

                    outputStreamWriter = new OutputStreamWriter(getActivity().getApplicationContext().openFileOutput("DatiUtente.txt", Context.MODE_PRIVATE));
                    outputStreamWriter.write("183\n" +
                            "80\n" +
                            "uomo\n" +
                            "1999-03-21\n" +
                            "MODERATO\n" +
                            "true\n" +
                            "true:true:true:true:true:true:true:true");
                    outputStreamWriter.close();

                    outputStreamWriter = new OutputStreamWriter(getActivity().getApplicationContext().openFileOutput("dieta.txt", Context.MODE_PRIVATE));
                    outputStreamWriter.write("");
                    outputStreamWriter.close();

                    outputStreamWriter = new OutputStreamWriter(getActivity().getApplicationContext().openFileOutput("pasti.txt", Context.MODE_PRIVATE));
                    outputStreamWriter.write("");
                    outputStreamWriter.close();

                    outputStreamWriter = new OutputStreamWriter(getActivity().getApplicationContext().openFileOutput("ricette.txt", Context.MODE_PRIVATE));
                    outputStreamWriter.write("fette biscottate e marmellata:280:COLAZIONE\n" +
                            "yogurt con muesli:217:SPUNTINO\n" +
                            "riso:350:PRANZO\n" +
                            "melanzane arrostite:30:PRANZO\n" +
                            "sgombro:170:PRANZO\n" +
                            "pane integrale:237:CENA\n" +
                            "cetrioli:16:CENA\n" +
                            "petto di pollo:104:CENA\n" +
                            "te con 3 biscotti: 48:COLAZIONE\n" +
                            "pompelmo rosa:42:SPUNTINO\n" +
                            "pane con bresaola, rucola e parmigiano:253:PRANZO\n" +
                            "mele:42:SPUNTINO\n" +
                            "fagiolini:24:CENA\n" +
                            "ricotta di vacca:150:CENA\n" +
                            "muesli con latte:110:COLAZIONE\n" +
                            "kiwi:61:SPUNTINO\n" +
                            "riso con tonno e pomodori:143:PRANZO\n" +
                            "pane di grano duro:266:CENA\n" +
                            "finocchi:25:CENA\n" +
                            "petto di tacchino:106:CENA\n" +
                            "pasta con acciughe:184:PRANZO\n" +
                            "mozzarella:232:CENA\n" +
                            "zucchine:21:CENA\n" +
                            "spremuta di pompelmo:34:COLAZIONE\n" +
                            "mandorle dolci:614:COLAZIONE\n" +
                            "yogurt magro:78:SPUNTINO\n" +
                            "crackers integrali:458:SPUNTINO\n" +
                            "pasta al ragu:134:PRANZO\n" +
                            "carote:41:PRANZO\n" +
                            "riso parboiled:339:CENA\n" +
                            "pesce spada grigliato:135:CENA\n" +
                            "tonno grigliato:136:CENA\n" +
                            "latte parzialmente scremato:46:COLAZIONE\n" +
                            "gnocchi ricotta e spinaci:136:PRANZO\n" +
                            "trota grigliata:145:PRANZO\n" +
                            "fagioli:294:CENA\n" +
                            "ananas:40:CENA\n" +
                            "grissini integrali:393:SPUNTINO\n" +
                            "gamberetti bolliti:68:PRANZO\n" +
                            "fragole:30:SPUNTINO\n" +
                            "patate:84:CENA\n" +
                            "wurstel di pollo:214:CENA\n" +
                            "agnello arrosto:265:PRANZO\n" +
                            "cavolo cappuccio verde:25:PRANZO\n" +
                            "camembert:299:PRANZO\n" +
                            "banane:76:PRANZO\n" +
                            "bresaola:168:CENA\n" +
                            "pane di segale:233:CENA\n" +
                            "tortelli di zucca:207:PRANZO");
                    outputStreamWriter.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        return view;
    }
}
