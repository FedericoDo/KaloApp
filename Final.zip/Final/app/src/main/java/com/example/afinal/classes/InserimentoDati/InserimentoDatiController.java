package com.example.afinal.classes.InserimentoDati;

import android.content.Context;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.Map;

import com.example.afinal.classes.Dominio.*;
import com.example.afinal.classes.GestoreFile.GestoreFile;

public class InserimentoDatiController {

    private GestoreFile controller;
    private Context c;

    public InserimentoDatiController(Context c) {
        this.c = c;
        controller = new GestoreFile(c);
    }

    public void inserisciDatiProfilo(DatiUtente dati, boolean[] settato) throws IOException {
        DatiUtente current = controller.getDatiFromFile();

        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(c.openFileOutput("DatiUtente.txt", Context.MODE_PRIVATE));
        if(settato[0]) outputStreamWriter.write(Integer.toString(dati.getAltezza()));
        else outputStreamWriter.write(current.getAltezza());
        outputStreamWriter.append("\n");

        if(settato[1]) outputStreamWriter.append(String.valueOf(dati.getPeso()));
        else outputStreamWriter.append(String.valueOf(current.getPeso()));
        outputStreamWriter.append("\n");

        if(settato[2]) outputStreamWriter.append(dati.getSesso());
        else outputStreamWriter.append(current.getSesso());
        outputStreamWriter.append("\n");

        if(settato[3]) outputStreamWriter.append(dati.getDataDiNascita().toString());
        else outputStreamWriter.append(current.getDataDiNascita().toString());
        outputStreamWriter.append("\n");

        if(settato[4]) outputStreamWriter.append(dati.getLaf().toString().toUpperCase());
        else outputStreamWriter.append(current.getLaf().toString().toUpperCase());
        outputStreamWriter.append("\n");

        if(settato[5]) outputStreamWriter.append(String.valueOf(dati.isAf()));
        else outputStreamWriter.append(String.valueOf(current.isAf()));
        outputStreamWriter.append("\n");

        for(boolean b : dati.getPermessi())
            outputStreamWriter.append(b+":");

        outputStreamWriter.close();
    }

    //Quantita è intesa in 100 grammi, espressa in grammi
    public void inserisciRicetta(String nome, List<String> nomi, List<Float> quantita, Tipo tipo) {
        //File alimenti.txt formattato in questo modo nome:calorie per ogni riga
        //File ricette.txt nello stesso modo
        float totCalorie=0;
        //Gli alimenti vengono scelti nell'interfaccia da quelli esistenti, quindi sono tutti validi
        try {
            List<Alimento> l = controller.getAlimentiFromFile();
            for(String n : nomi){
                for(Alimento a : l) {
                    if (a.getNome().equals(n)) {
                        totCalorie += (a.getCalorie() / 100) * quantita.get(nomi.indexOf(n));
                        break;
                    }//if
                }
            }//for

            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(c.openFileOutput("ricette.txt", Context.MODE_APPEND));
            outputStreamWriter.append("\n");
            outputStreamWriter.append(nome+":"+totCalorie+":"+tipo.toString().toUpperCase());

            outputStreamWriter.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //p è null se il pasto è stato rispettato
    public void inserisciPasto(boolean prog, String tipo, Pasto p){
        //Il non rispetto della dieta viene calcolato solo alla fine del giorno
        //Nell'interfaccia visualizzo il prossimo pasto da fare e dico: hai fatto questo? se no lo faccio
        //inserire
        //C'è un file pasti.txt nel seguente formato:
        //nGiorno:tipo:V/F(se è stato rispettato o no):nomeRicetta:quantita(ultimi due ci sono se non è stato rispettato il pasto e contengono il pasto fatto)
        try {
            int dayOfWeek = controller.getDayOfWeek();

            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(c.openFileOutput("pasti.txt", Context.MODE_APPEND));
            if (prog) {
                outputStreamWriter.append("\n");
                outputStreamWriter.append(dayOfWeek+":"+tipo+":V");
            } else {
                outputStreamWriter.append("\n");;
                outputStreamWriter.append(dayOfWeek+":"+tipo+":F");
                for(Map.Entry<Ricetta, Float> e : p.getRicette().entrySet()){
                    outputStreamWriter.append(":"+e.getKey().getNome()+":"+e.getValue());
                }
                controller.aggiornaSurplus(dayOfWeek, tipo, p);
            }
            outputStreamWriter.close();

            float surplusAttuale = controller.getSurplusAttuale();
            if(tipo.equalsIgnoreCase("CENA") && surplusAttuale > 0){
                List<AttivitaFisica> lista = controller.getAllAttivita();
                AttivitaFisica at = lista.get((int) (Math.random() * (lista.size())));
                at.setMinuti((int) (surplusAttuale/at.getCaloriePerMinuto()));

                outputStreamWriter = new OutputStreamWriter(c.openFileOutput("attivitaFisica.txt", Context.MODE_APPEND));

                outputStreamWriter.append("\n");
                outputStreamWriter.append(at.getNome()+":"+at.getMinuti());

                outputStreamWriter.close();
            } //if
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }


}
